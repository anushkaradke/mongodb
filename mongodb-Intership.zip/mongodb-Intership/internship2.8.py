#Write a program to accept salary and display all documents having salary greater than the input value

from pymongo import MongoClient

client=MongoClient('mongodb+srv://anushkaradke:505052amt@anushka.wq6f0is.mongodb.net/?retryWrites=true&w=majority')
db=client["office"]
coll=db["workers"]

sal=int(input("Enter salary :"))
dict={}
dict1={}
dict1["$gt"]=sal
dict["salary"]=dict1
for d in coll.find(dict):
    print(d)
