#Write a Python program to take input from the user and add employee data as a document in the collection (ex. ID, empnm, dept, post, city, salary, mobile, email)

from pymongo import MongoClient
client=MongoClient('mongodb+srv://anushkaradke:505052amt@anushka.wq6f0is.mongodb.net/?retryWrites=true&w=majority')
db=client["office"]
coll=db["workers"]
id=input("Enter your id :")
nm=input("Enter employee name : ")
d=input("Enter department : ")
p=input("Enter post : ")
c=input("Enter city : ")
sal=float(input("Enter salary : "))
mob=input("Enter mobile number : ")
em=input("Enter email : ")

dict={}
dict["_id"]=id
dict["empnm"]=nm
dict["dept"]=d
dict["post"]=p
dict["city"]=c
dict["salary"]=sal
dict["mobile"]=mob
dict["email"]=em

coll.insert_one(dict)
print("Record inserted")
