#Write a program to accept ID, fetch the document from collection, copy it in another collection "exworkers" and delete the document from the "workers" collection

from pymongo import MongoClient

client=MongoClient('mongodb+srv://anushkaradke:505052amt@anushka.wq6f0is.mongodb.net/?retryWrites=true&w=majority')
db=client["office"]
coll=db["workers"]
id = input("Enter the id : ")
dist={}
dist["_id"]=id
for d in coll.find(dist):
    print(d)
    coll.insert_one(d)
    coll.delete_one(dist)
print("Worker with id %s is deleted and inserted into collection exworkers"%id)
