#Write a program to show list of all documents from the collection

from pymongo import MongoClient
client=MongoClient('mongodb+srv://anushkaradke:505052amt@anushka.wq6f0is.mongodb.net/?retryWrites=true&w=majority')
db=client["office"]
coll=db["workers"]
for d in coll.find() :
  print(d)
