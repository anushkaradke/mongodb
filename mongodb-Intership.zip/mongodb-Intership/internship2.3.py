#Write a program take ID as input, search and display the worker document

from pymongo import MongoClient
client=MongoClient('mongodb+srv://anushkaradke:505052amt@anushka.wq6f0is.mongodb.net/?retryWrites=true&w=majority')
db=client["office"]
coll=db["workers"]

id=input("Enter the id : ")
dict={}
dict["_id"]=id
for d in coll.find(dict):
  print(d)
