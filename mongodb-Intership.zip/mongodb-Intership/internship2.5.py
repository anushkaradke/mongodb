#Write a program to accept ID and new salary of the worker. Update the document with new salary. Display the document after updation.

from pymongo import MongoClient
client=MongoClient('mongodb+srv://anushkaradke:505052amt@anushka.wq6f0is.mongodb.net/?retryWrites=true&w=majority')
db=client["office"]
coll=db["workers"]

id=input("Enter your id : ")
sal=float(input("Enter your new salary: "))
dict={}
dict["_id"]=id
dict1={}
dict1["salary"]=sal
dict2={"$set":dict1}
dict3={}
coll.update_one(dict,dict2)
print("Record updated")


