#Write a program take department as an input and display documents of all workers of the department

from pymongo import MongoClient
client=MongoClient('mongodb+srv://anushkaradke:505052amt@anushka.wq6f0is.mongodb.net/?retryWrites=true&w=majority')
db=client["office"]
coll=db["workers"]

d=input("Enter the department : ")
dict={}
dict["dept"]=d
for d in coll.find(dict):
  print(d)
