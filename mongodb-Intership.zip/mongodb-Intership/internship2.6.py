#Write a program to accept ID, city and department. Update the document with new city and department of the worker.

from pymongo import MongoClient
client=MongoClient('mongodb+srv://anushkaradke:505052amt@anushka.wq6f0is.mongodb.net/?retryWrites=true&w=majority')
db=client["office"]
coll=db["workers"]

id=input("Enter the id : ")
c=input("Enter city : ")
d=input("Enter the department : ")

dict={}
dict["_id"]=id
dict1={}
dict1["city"]=c
dict1["dept"]=d
dict2={"$set":dict1}
coll.update_one(dict,dict2)
print("Record updated")
